print(__name__.split(".")[-1])

# pas le droit  :     import dusty_gulch.boot_hill.cemetery_road   
#supprimer py cache, si ca chie

from .boot_hill import cemetery_road
